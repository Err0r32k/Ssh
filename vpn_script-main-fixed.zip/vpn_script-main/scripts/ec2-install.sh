#!/bin/bash
# EC2 bootstrap for Ubuntu on AWS — stanlley-locke/vpn_script (patched)
#
# Run on the EC2 instance as root, from a clone of the repo:
#   sudo -i
#   apt-get update -y && apt-get install -y git wget dnsutils
#   git clone https://github.com/stanlley-locke/vpn_script.git /root/vpn_script
#   bash /root/vpn_script/scripts/ec2-install.sh
#
# Optional non-interactive:  VPN_DOMAIN=vpn.example.com bash scripts/ec2-install.sh
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCAL_GENZ="${SCRIPT_DIR}/../genz.sh"
REPO="${VPN_REPO:-https://raw.githubusercontent.com/stanlley-locke/vpn_script/main/}"
ENV_DEST="/root/vpn_script.env"

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "Run as root: sudo bash ec2-install.sh"
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " VPN Script — Ubuntu EC2 install"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: sanity checks ────────────────────────────────────────────────
[[ "$(uname -m)" == "x86_64" ]] || { echo "Need an x86_64 instance (not Graviton/arm64)."; exit 1; }
. /etc/os-release
[[ "${ID:-}" == "ubuntu" || "${ID:-}" == "debian" ]] || echo "WARN: untested OS: ${PRETTY_NAME:-unknown}"

# PPA cleanup — file removal only (add-apt-repository can segfault)
rm -f /etc/apt/sources.list.d/*vbernat* /etc/apt/sources.list.d/haproxy.list 2>/dev/null || true
sed -i '/vbernat\/haproxy/d' /etc/apt/sources.list 2>/dev/null || true

# ── Step 2: base tools ───────────────────────────────────────────────────
apt-get update -y
apt-get install -y wget ca-certificates dnsutils git unzip

# ── Step 3: public IP (EC2 metadata v2 first, then public lookup) ────────
get_ip() {
    local t ip
    t=$(wget -qO- --timeout=3 --method=PUT --header="X-aws-ec2-metadata-token-ttl-seconds: 60" \
        http://169.254.169.254/latest/api/token 2>/dev/null || true)
    if [[ -n "$t" ]]; then
        ip=$(wget -qO- --timeout=3 --header="X-aws-ec2-metadata-token: $t" \
            http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || true)
    fi
    [[ -n "$ip" ]] || ip=$(wget -qO- --timeout=8 ipv4.icanhazip.com 2>/dev/null || true)
    echo "$ip"
}
MYIP="$(get_ip)"
[[ -n "$MYIP" ]] || { echo "Cannot detect public IP. Does the instance have a public/Elastic IP?"; exit 1; }
echo "Public IP: ${MYIP}"

# ── Step 4: domain (YOUR domain — no default) ────────────────────────────
DOMAIN="${VPN_DOMAIN:-}"
if [[ -z "$DOMAIN" ]]; then
    read -rp "Enter your domain/subdomain (A record must point to ${MYIP}): " DOMAIN
fi
[[ -n "$DOMAIN" ]] || { echo "Domain is required."; exit 1; }

RESOLVED="$(dig +short A "$DOMAIN" | tail -1)"
if [[ -z "$RESOLVED" ]]; then
    echo "ERROR: ${DOMAIN} has no A record. Create:  ${DOMAIN}  A  ${MYIP}  (DNS only), wait 1-5 min, then re-run."
    exit 1
elif [[ "$RESOLVED" != "$MYIP" ]]; then
    echo "WARN: ${DOMAIN} resolves to ${RESOLVED}, this server is ${MYIP}."
    echo "      Fine only if the Cloudflare orange cloud is on. Otherwise certificate issuing will fail."
    read -rp "Continue anyway? [y/N] " yn
    [[ "$yn" == "y" || "$yn" == "Y" ]] || exit 1
else
    echo "DNS OK: ${DOMAIN} -> ${RESOLVED}"
fi

# ── Step 5: write env (keep an existing one) ─────────────────────────────
if [[ ! -f "$ENV_DEST" ]]; then
    cat > "$ENV_DEST" <<EOF
VPN_DOMAIN="${DOMAIN}"
VPS_PUBLIC_IP="${MYIP}"
VPS_PROVIDER="aws-ec2"
LICENSE_CHECK="0"
INSTALL_NOTIFY="0"
CF_DNS_PROXIED="0"
SNI_FRONTING="${DOMAIN}"
EOF
    chmod 600 "$ENV_DEST"
    echo "Saved ${ENV_DEST}"
else
    echo "Using existing ${ENV_DEST}"
    # keep it in sync with the domain just confirmed
    sed -i "s|^VPN_DOMAIN=.*|VPN_DOMAIN=\"${DOMAIN}\"|" "$ENV_DEST"
fi

set -a
# shellcheck source=/dev/null
source "$ENV_DEST"
set +a
export VPN_ENV_FILE="$ENV_DEST"
export VPN_AUTO_INSTALL=1

# ── Step 6: run the installer (local patched copy preferred) ─────────────
if [[ -f "$LOCAL_GENZ" ]]; then
    echo "Using local installer: $(readlink -f "$LOCAL_GENZ")"
    exec bash "$LOCAL_GENZ"
fi
wget -qO /tmp/genz.sh "${REPO}genz.sh" || { echo "Failed to download genz.sh"; exit 1; }
exec bash /tmp/genz.sh
